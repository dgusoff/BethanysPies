vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Jul 2002 17:59:30 -0000
vti_extenderversion:SR|4.0.2.5526
