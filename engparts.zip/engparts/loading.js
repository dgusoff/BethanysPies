n=document.layers;
ie=document.all;

// Hides the layer onload
function hideWait() {
	if (ie) {
			divLoadBar.style.visibility="hidden";
	}
}

function showWait() {
	if (ie) {
			divLoadBar.style.visibility="visible";
	}
}
function showWait2() {
// We write the table and the div to hide the content out, so older browsers won't see it
if (ie) {
	document.writeln("<DIV ID='divLoadCont' style='Z-INDEX:100; LEFT:5px; FONT-FAMILY: arial,helvetica; POSITION:absolute; TOP:220px; background-color:white;'>");
	document.writeln("<LAYER NAME='divLoadCont'>");	document.writeln('<table width="100" cellspacing="0" cellpadding="0" border="0">');
	document.writeln('<tr>');
	document.writeln('<td style="TEXT-ALIGN: center;BACKGROUND-COLOR: #FF99FF">');
	document.writeln('<font style="color: 003333; font-family: helvetica; font-size: 16px; font-weight: bold; text-decoration: none; align=center;"><BR>&nbspLoading&#133;</font>');	//document.writeln('<BR>');
	document.writeln('<font style="color: 000000; font-family: verdana; font-size: 13px; font-weight: normal; text-decoration: none; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px;">');
	document.writeln('<BR><BR>&nbspPlease wait.</font><p></td>');	document.writeln("</SPAN>");
	document.writeln('</tr>');	document.writeln('<tr>');	document.writeln('<td style="TEXT-ALIGN:center;valign=middle"><p><IMG SRC="img/please_wait_loading.gif" ALT="" BORDER="0" vspace=2><P></td>');
	document.writeln('</tr>');
	document.writeln('</table>');
	document.writeln("</DIV>");
	document.write("</LAYER>");	
}}
