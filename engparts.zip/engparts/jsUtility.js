function GetCookie(name) {
var dcookie = document.cookie; 
var cname = name + "=";
var clen = dcookie.length;
var cbegin = 0;
        while (cbegin < clen) {
        var vbegin = cbegin + cname.length;
                if (dcookie.substring(cbegin, vbegin) == cname) { 
                var vend = dcookie.indexOf (";", vbegin);
                        if (vend == -1) vend = clen;
                return unescape(dcookie.substring(vbegin, vend));
                }
        cbegin = dcookie.indexOf(" ", cbegin) + 1;
                if (cbegin == 0) break;
        }
return null;
}

function SetCookie(name, value) {
    var expdate = new Date;
        expdate.setTime (expdate.getTime() + (24 * 60 * 60 * 1000 * 365));
    var argv = SetCookie.arguments;
    var argc = SetCookie.arguments.length;
    var expires = (argc > 2) ? argv[2] : expdate;
    var path = (argc > 3) ? argv[3] : null;
    var domain = (argc > 4) ? argv[4] : null;
    var secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape (value) +
    ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
    ((path == null) ? "" : ("; path=" + path)) +
    ((domain == null) ? "" : ("; domain=" + domain)) +
    ((secure == true) ? "; secure" : "");
}

function DelCookie(name) {
var expireNow = new Date();
document.cookie = name + "=" +
"; expires=Thu, 01-Jan-70 00:00:01 GMT" +  "; path=/";
}
